function setup() {
  createCanvas(500, 500);
}

function draw() {
  background(255, 255, 255);
  ellipse(250, 150, 200, 200);
  fill(0, 0, 255, 63)
  noStroke()
  ellipse(185, 265, 200, 200);
  fill(0, 255, 0, 63)
  noStroke()
  ellipse(315, 265, 200, 200);
  fill(255, 0, 0, 63)
  noStroke()
}

