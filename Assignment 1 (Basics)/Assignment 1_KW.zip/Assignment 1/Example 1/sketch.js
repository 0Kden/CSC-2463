function setup() {
  createCanvas(500, 250);
}

function draw() {
  background(0,255,0);
  ellipse(125, 125, 200, 200);
  rect(275, 25, 200, 200);
 
}

